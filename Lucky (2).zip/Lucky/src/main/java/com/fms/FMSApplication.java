package com.fms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class FMSApplication {

	public static void main(String[] args) {
		SpringApplication.run(FMSApplication.class, args);
	}

}