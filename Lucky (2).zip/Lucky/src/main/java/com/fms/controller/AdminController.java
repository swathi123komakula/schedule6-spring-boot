package com.fms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fms.dto.Airport;
import com.fms.dto.Scheduledflight;
import com.fms.exception.IdNotFoundException;
import com.fms.service.ScheduledflightService;

@RestController
@RequestMapping("/admin")
@CrossOrigin(origins="http://localhost:4200", maxAge=3600)
public class AdminController {
	

	 @Autowired
	 private ScheduledflightService scheduleservice;
     @PostMapping(value="/addScheduledFlight/{flightnumber}/{sourceairport}/{destinationairport}")
     public ResponseEntity<String> addScheduledFlight(@RequestBody Scheduledflight sf, @PathVariable int flightnumber,@PathVariable String sourceairport, @PathVariable String destinationairport)
     {
    	 Scheduledflight sfg1= scheduleservice.addScheduledflight(sf, flightnumber,sourceairport,destinationairport);
    	 System.out.println(sfg1);
    		if (sfg1 == null) {
    			throw new IdNotFoundException("Enter Valid Id");
    		} else {
    			return new ResponseEntity<String>("flight details added successfully", new HttpHeaders(), HttpStatus.OK);
    		}
     }
	 
	 @PutMapping("/updatescheduledflight/{flightnumber}/{sourceairport}/{destinationairport}")
		public String updateFlight( @RequestBody Scheduledflight schedule,@PathVariable int flightnumber,@PathVariable String sourceairport, @PathVariable String destinationairport) {
			
				 scheduleservice.updateScheduleFlight(schedule,flightnumber,sourceairport,destinationairport);
				 return "Scheduled flight details are updated";
	    }
	 
	 @DeleteMapping("/deletescheduledflight/{scheduledflightid}")
	 public String deleteScheduledFlight(@PathVariable int scheduledflightid)
     {
    	 scheduleservice.deleteScheduledFlight(scheduledflightid);
    	 return "Scheduled flight Details Deleted";
     }
	 
	 @GetMapping("/getAllscheduledflights")
	 public List<Scheduledflight> viewScheduledFlight()
	    {
	   	 return scheduleservice.viewScheduledFlight();
	    }
	 
	 @GetMapping(value="/getScheduledFlight/{scheduledid}",produces="application/json")
     public Scheduledflight viewScheduledFlight(@PathVariable int scheduledid)
     {
    	 return scheduleservice.viewScheduledFlight(scheduledid);
     }
	 
	
	 
	 @PostMapping("/Addairport")
		public Airport addAirport(@RequestBody Airport airport) {
		 
			return scheduleservice.addAirport(airport);
			
		}
	  
}		
		
				

			
							
				
							
			

			

			
			
			

			
				
				
